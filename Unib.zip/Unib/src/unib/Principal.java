package unib;

import view.TelaInicio;

public class Principal {

    public static void main(String[] args) {
        
        TelaInicio ti = new TelaInicio();
        ti.setVisible(true);
        
    }
    
}
